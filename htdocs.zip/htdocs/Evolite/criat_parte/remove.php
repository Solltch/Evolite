<?php
require_once "../config.php";

$id_criatura = $_POST["id_criatura"];
$id_parte    = $_POST["id_parte"];
$tipo_parte  = $_POST["tipo_parte"];

$stmt = $conn->prepare("
    DELETE FROM criat_parte 
    WHERE id_criatura=? AND id_parte=? AND tipo_parte=?
");
$stmt->bind_param("iii", $id_criatura, $id_parte, $tipo_parte);

echo json_encode(["status" => $stmt->execute()]);
?>