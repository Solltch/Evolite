<?php
require_once "../config.php";

// Recebe dados brutos do POST
$id_criatura = $_POST["id_criatura"];

// Recebe as partes como arrays
$id_partes     = $_POST["id_partes"];      // array de IDs de parte
$tipos_partes  = $_POST["tipos_partes"];   // array de tipos
$equipadas     = $_POST["equipadas"];      // array de 0 ou 1

if (!is_array($id_partes) || !is_array($tipos_partes) || !is_array($equipadas)) {
    http_response_code(400);
    echo "ERRO: Arrays de partes inválidos";
    exit;
}

if (count($id_partes) !== 6 || count($tipos_partes) !== 6 || count($equipadas) !== 6) {
    http_response_code(400);
    echo "ERRO: Precisam ser exatamente 6 partes";
    exit;
}

$query = "INSERT INTO criat_parte (id_criatura, id_parte, tipo_parte, equipada)
          VALUES (?, ?, ?, ?)
          ON DUPLICATE KEY UPDATE 
            id_parte = VALUES(id_parte),
            equipada = VALUES(equipada)";

$stmt = $conn->prepare($query);

if (!$stmt) {
    http_response_code(500);
    echo "ERRO_SQL: " . $conn->error;
    exit;
}

$stmt->bind_param("iiii", $id_criatura_item, $id_parte_item, $tipo_parte_item, $equipada_item);

$salvos = 0;
$falhas  = 0;

for ($i = 0; $i < 6; $i++) {
    $id_criatura_item = $id_criatura;
    $id_parte_item    = intval($id_partes[$i]);
    $tipo_parte_item  = intval($tipos_partes[$i]);
    $equipada_item    = intval($equipadas[$i]);

    if ($stmt->execute()) {
        $salvos++;
    } else {
        $falhas++;
        error_log("Falha ao salvar parte {$i}: " . $stmt->error);
    }
}

$stmt->close();
$conn->close();

echo "RESULTADO: $salvos partes salvas, $falhas falhas";
?>
