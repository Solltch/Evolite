<?php
require_once "../config.php";

// Inclua seu arquivo de conexão com o banco de dados
// Ex: include 'db_connect.php'; 
// Assumindo que $conn é sua conexão mysqli ou PDO

// 1. Verifica se o ID da criatura foi fornecido
if (!isset($_GET['id_criatura']) || !is_numeric($_GET['id_criatura'])) {
    http_response_code(400);
    echo "ERRO: ID da criatura não fornecido ou inválido.";
    exit;
}

$id_criatura = intval($_GET['id_criatura']);
$partes = [];

// 2. Consulta SQL
// Ajuste os nomes das colunas e da tabela conforme seu schema
$sql = "SELECT id_criatura, id_parte, tipo_parte 
        FROM criat_parte 
        WHERE id_criatura = ?"; // Apenas partes equipadas

// Usando prepared statements para segurança
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $id_criatura);
    $stmt->execute();
    $result = $stmt->get_result();

    // 3. Processa os resultados
    while ($row = $result->fetch_assoc()) {
        $partes[] = [
            'id_criatura' => (int)$row['id_criatura'],
            'id_parte' => (int)$row['id_parte'],
            'tipo_parte' => (int)$row['tipo_parte']
        ];
    }
    $stmt->close();
} else {
    http_response_code(500);
    echo "ERRO: Falha na preparação da consulta: " . $conn->error;
    exit;
}

// 4. Retorna o array de objetos JSON
if (empty($partes)) {
    // Retorna um array vazio se nada for encontrado, ou um erro específico se preferir
    echo json_encode([]);
} else {
    echo json_encode($partes);
}

// Opcional: Fechar a conexão
// $conn->close();

?>