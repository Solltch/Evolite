<?php
include '../config.php';

// 1. Recebe a ID da Criatura (única)
$id_criatura = $_POST['id_criatura'];

// 2. Recebe as Partes como ARRAYS (enviadas pelo C# com "[]")
$ids_partes   = $_POST['id_partes'];
$tipos_partes = $_POST['tipos_partes'];
$equipadas    = $_POST['equipadas']; // Embora o C# mande sempre 1, é bom processar

// Validação básica
if (
    !isset($id_criatura) || 
    !is_array($ids_partes) || 
    !is_array($tipos_partes) || 
    count($ids_partes) != count($tipos_partes)
) {
    // Retorna uma mensagem de erro clara
    echo "ERRO: Dados insuficientes ou mal formatados.";
    exit;
}

$sucessos = 0;
$falhas = 0;
$total_partes = count($ids_partes);

// 3. Itera sobre cada parte para realizar o Upsert
for ($i = 0; $i < $total_partes; $i++) {
    // Valores da parte atual
    $id_parte_atual   = $ids_partes[$i];
    $tipo_parte_atual = $tipos_partes[$i];
    $equipada_atual   = $equipadas[$i] ?? 1; // Usa 1 como fallback se não houver 'equipadas'

    // Evita IDs de parte vazias/zero (opcional, mas bom)
    // if (empty($id_parte_atual) || empty($tipo_parte_atual)) {
    //     $falhas++;
    //     continue;
    // }

    /* Lógica: SELECT -> UPDATE ou INSERT */

    // 4. SELECT: Verifica se o registro já existe para esta criatura e este tipo de parte
    $sql = "SELECT id_parte, id_Criatura FROM criat_parte WHERE id_criatura=? AND tipo_parte=? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id_criatura, $tipo_parte_atual);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // UPDATE: Atualiza o id_parte e equipada
        $update = $conn->prepare("UPDATE criat_parte SET id_parte=?, equipada=? WHERE id_criatura=? AND tipo_parte=?");
        $update->bind_param("iiii", $id_parte_atual, $equipada_atual, $id_criatura, $tipo_parte_atual);

        if ($update->execute()) {
            $sucessos++;
        } else {
            $falhas++;
        }
        $update->close();
    } else {
        // INSERT: Insere um novo registro
        $insert = $conn->prepare("INSERT INTO criat_parte(id_criatura,id_parte,tipo_parte,equipada) VALUES (?,?,?,?)");
        $insert->bind_param("iiii", $id_criatura, $id_parte_atual, $tipo_parte_atual, $equipada_atual);

        if ($insert->execute()) {
            $sucessos++;
        } else {
            $falhas++;
        }
        $insert->close();
    }
    $stmt->close();
}

// 5. Retorna o resultado consolidado para o C#
echo "RESULTADO: {$sucessos} partes salvas ({$total_partes} enviadas), {$falhas} falhas.";

?>