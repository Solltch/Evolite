<?php
require_once "../config.php";

$username = $_POST['username'] ?? '';
$senha = $_POST['senha'] ?? '';

if(empty($username) || empty($senha)){
    echo json_encode(["status"=>"erro","msg"=>"dados_incompletos"]);
    exit;
}

// Verifica se já existe
$sql = "SELECT id FROM usuario WHERE username='$username'";
$res = mysqli_query($conn, $sql);

if(mysqli_num_rows($res) > 0){
    echo json_encode(["status"=>"erro", "msg"=>"username_ja_existe"]);
    exit;
}

// Cria usuário
$sql = "INSERT INTO usuario (username, senha) VALUES ('$username', '$senha')";
if(mysqli_query($conn, $sql)){
    echo json_encode(["status"=>"ok", "msg"=>"usuario_criado"]);
} else {
    echo json_encode(["status"=>"erro","msg"=>"falha_no_servidor"]);
}
?>
