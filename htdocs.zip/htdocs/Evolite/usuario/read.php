<?php
require_once "../config.php";

$username = $_POST['username'];
$senha = $_POST['senha'];

$stmt = $conn->prepare("SELECT id, username FROM usuario WHERE username=? AND senha=? LIMIT 1");
$stmt->bind_param("ss", $username, $senha);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 0) {
    echo "ERRO|Usuário ou senha incorretos";
    exit;
}

$stmt->bind_result($id, $user);
$stmt->fetch();

echo "OK|$id|$user";
?>
