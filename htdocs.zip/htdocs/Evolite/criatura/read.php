<?php
require_once "../config.php";

$idc = $_GET["id_criador"] ?? "";
$stmt = $conn->prepare("SELECT * FROM criatura WHERE id_criador=?");
$stmt->bind_param("i",$idc);
$stmt->execute();

echo json_encode($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
?>
