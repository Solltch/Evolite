<?php
require_once "../config.php";

$id = $_GET["id"] ?? 0;
if(!$id){
    echo json_encode(["success"=>false,"message"=>"ID inválido"]);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM criatura WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

if($result){
    echo json_encode([
        "success" => true,
        "message" => "Encontrado",
        "criatura" => $result
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Criatura não encontrada"
    ]);
}
?>
