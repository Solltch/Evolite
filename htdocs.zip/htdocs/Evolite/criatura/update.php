<?php
require_once "../config.php";

$id = $_POST['id'] ?? 0;
$nome = $_POST['nome'] ?? '';

if(!$id || !$nome){
    http_response_code(400);
    echo json_encode(["success"=>false,"message"=>"Dados inválidos"]);
    exit;
}

$stmt = $conn->prepare("UPDATE criatura SET nome=? WHERE id=?");
$stmt->bind_param("si", $nome, $id);
if($stmt->execute()){
    echo json_encode(["success"=>true,"message"=>"Atualizado"]);
}else{
    echo json_encode(["success"=>false,"message"=>$stmt->error]);
}
$stmt->close();
$conn->close();
?>
