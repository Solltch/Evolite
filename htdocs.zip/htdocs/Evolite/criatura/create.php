<?php
require_once "../config.php";

$id_criador = $_POST["id_criador"] ?? "";
$nome       = $_POST["nome"]       ?? "";

$stmt = $conn->prepare("INSERT INTO criatura (id_criador,nome) VALUES (?,?)");
$stmt->bind_param("is",$id_criador,$nome);
echo $stmt->execute() ? $conn->insert_id : "erro";
?>
