<?php
require_once "../config.php";

$result = $conn->query("SELECT * FROM parte");
echo json_encode($result->fetch_all(MYSQLI_ASSOC));
?>