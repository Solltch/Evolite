<?php
require_once "../config.php";

$id_criatura  = $_POST["id_criatura"];
$id_habilidade = $_POST["id_habilidade"];

$stmt = $conn->prepare("INSERT INTO criat_habil (id_criatura, id_habilidade) VALUES (?, ?)");
$stmt->bind_param("ii", $id_criatura, $id_habilidade);

echo json_encode(["status" => $stmt->execute()]);
?>