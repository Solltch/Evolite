<?php
require_once "../config.php";

$id_criatura = $_GET["id_criatura"];

$stmt = $conn->prepare("
    SELECT h.* 
    FROM criat_habil ch
    JOIN habilidade h ON ch.id_habilidade = h.id
    WHERE ch.id_criatura = ?
");
$stmt->bind_param("i", $id_criatura);
$stmt->execute();

echo json_encode($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
?>