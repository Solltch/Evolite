<?php
require_once "../config.php";

$id_criatura = $_POST["id_criatura"];
$id_habilidade = $_POST["id_habilidade"];

$stmt = $conn->prepare("DELETE FROM criat_habil WHERE id_criatura=? AND id_habilidade=?");
$stmt->bind_param("ii", $id_criatura, $id_habilidade);

echo json_encode(["status" => $stmt->execute()]);
?>