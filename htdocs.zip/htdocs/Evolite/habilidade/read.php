<?php
// habilidade/read.php
require_once "../config.php";

$result = $conn->query("SELECT id, nome, descricao, custo_DNA FROM habilidade");

$output = "";
while ($row = $result->fetch_assoc()) {
    // Retorna os campos separados por ponto e vírgula, seguidos por uma nova linha
    $output .= $row['id'] . ";" . $row['nome'] . ";" . $row['descricao'] . ";" . $row['custo_DNA'] . "\n";
}
echo trim($output); 
?>