<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "criaturasdb";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

header("Content-Type: application/json; charset=UTF-8");
?>